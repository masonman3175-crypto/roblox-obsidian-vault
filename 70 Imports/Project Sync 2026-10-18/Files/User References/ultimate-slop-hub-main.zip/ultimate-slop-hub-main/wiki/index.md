---
type: index
game: hub
owner: shared
updated: 2026-10-17
---

# Wiki Index

Catalog of every page. AI reads this first and updates it on every ingest. Format: `- [[Page]] - summary (status)`.
Rules: Wiki schema in `CLAUDE.md` / `AGENTS.md`. Timeline: [[log]].

## Hub
- [[00 Hub]] - start page, list of games (building)
- [[Slop Blueprint]] - homepage game recipe: loop, build order, numbers (building)
- [[Monetization And Compliance]] - allowed / not allowed, server-side purchases (building)
- [[Studio Layout]] - standard place layout and remotes (building)

## Games
- [[Stat Sim Design]] - +1 stat tower simulator, Cade, place 98823628319724 (building)
- [[Stat Sim Next Pass]] - Stat Sim task list (building)

## References
- [[Homepage Trends Oct 2026]] - +1 titles, weak-to-strong thumbnails, stud walls (idea)
- [[Rocket Boots Speed Sim]] - level bar, rebirth x1.5, buy-level buttons, treadmill tiers (idea)
- [[Keyboard Escape Sim]] - late-game HUD, multiplier breakdown, starter pack, events (idea)

## Systems
- [[Level And Rebirth Curve]] - XP, level, rebirth numbers seen and our start curve (planned)

## Monetization
- [[Simulator Monetization Touchpoints]] - every Robux touchpoint and price seen (planned)

## UI
- [[Simulator HUD Layout]] - standard sim HUD map (planned)
- [[Sim Button Anatomy]] - chunky button/panel layers, UiStyle module recipe (building)

## Maps
- [[Stat Sim Map]] - Stat Sim v2 art: punch arena, tier gym, egg + portal plazas, cliffs/pond, worlds 2-5 islands, lighting (building)
- [[Stat Sim Punch Track]] - 6 biome punch track, arches, distance boards, MAX wall (building)

## VFX
(none yet)

## Tools
- [[Script Mirror]] - copy every Studio script into games/<Game>/src via a local receiver (shipped)
- [[Studio MCP Reference]] - setup and tool list for Roblox's Studio MCP (building)
- [[Studio MCP Gotchas]] - things that bit us building through the MCP (building)
- [[Store Asset Vetting]] - checklist for free store models, backdoor scripts (building)
- [[Blender MCP]] - AI drives Blender for props (building)

## Devlog
- [[2026-10-17]] - hub set up (shipped)
