---
type: game
game: {{title}}
owner: cade / partner
status: idea
place_id: 
sources: []
updated: {{date:YYYY-MM-DD}}
---

# {{title}} Design

## Pitch
One line.

## Loop
Join > gain > unlock > rebirth (see [[Slop Blueprint]])

## Stats and numbers

## Zones

## Rebirth

## Monetization
(see [[Monetization And Compliance]])

## Studio
Place id, layout per [[Studio Layout]].

## Related
- [[index]]
