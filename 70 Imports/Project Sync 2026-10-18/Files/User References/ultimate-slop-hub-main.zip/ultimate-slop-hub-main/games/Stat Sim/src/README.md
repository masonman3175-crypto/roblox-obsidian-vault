# Stat Sim source mirror

Copy of every script in the Stat Sim place, exported by the AI after each change. Studio is the source of truth; this folder is the backup and the diff history.

Paths mirror the Explorer: `ServerScriptService/Services/DataService.luau` etc. See [[Studio Layout]].
